package com.clipg.aiagent.demo.invoke;

public interface TestApiKey {

    String API_KEY = "sk-b278fb2336e74e5e99069e6c5845d877";

}
